#include "SH1106.h"
#include "lcd_generic_font.h"

#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "core_cmInstr.h"


unsigned char TimeX = 2;

char mask;
int xpos;

int vmirror = 0;


//-----------------I2C Program------------------------------------------------/
inline void _delay_loops(uint32_t loops) {
	 __asm__ __volatile__
	 (
	                "1: \n"
	                " CBZ %[loops], 2f \n"
	                " SUB %[loops], %[loops], #1 \n"
	                " B 1b \n"
	                "2: \n"
	                : [loops] "+r"(loops)
	 );
}



void I2C_Start(void)
{
	GPIOB->BSRR = OLED_SDA;  //GPIOB->BSRR = (1<<I2C_SDA_PIN);
	_delay_loops(TimeX);
	GPIOB->BSRR = OLED_SCL;  //I2C_SCL_PORT->BSRR = (1<<I2C_SCL_PIN);
	_delay_loops(TimeX);
	while(!(GPIOB->IDR & OLED_SDA))
	{
		GPIOB->BRR = OLED_SCL;  //I2C_SCL_PORT->BRR  = (1<<I2C_SCL_PIN);
		_delay_loops(TimeX);
	    GPIOB->BSRR = OLED_SCL;  //I2C_SCL_PORT->BSRR = (1<<I2C_SCL_PIN);
	    _delay_loops(TimeX);
	}
	GPIOB->BRR = OLED_SDA;//I2C_SDA_PORT->BRR = (1<<I2C_SDA_PIN);
	_delay_loops(TimeX);
	GPIOB->BRR = OLED_SCL;//I2C_SCL_PORT->BRR = (1<<I2C_SCL_PIN);
	_delay_loops(TimeX);

}
void I2C_Stop(void)
{
	GPIOB->BRR = OLED_SDA;//I2C_SDA_PORT->BRR = (1<<I2C_SDA_PIN);
	_delay_loops(TimeX);
	GPIOB->BSRR = OLED_SCL;//I2C_SCL_PORT->BSRR = (1<<I2C_SCL_PIN);
	_delay_loops(TimeX);
	GPIOB->BSRR = OLED_SDA;//I2C_SDA_PORT->BSRR = (1<<I2C_SDA_PIN);
	_delay_loops(TimeX);

}

void __attribute__ ((noinline)) I2C_WriteData(unsigned char data)
{
	uint8_t i;
	uint8_t ACK;

	for(i=0;i<8;i++)
	{
	   if (data & 0x80)
		   GPIOB->BSRR = OLED_SDA;//I2C_SDA_PORT->BSRR = (1<<I2C_SDA_PIN);
	   else
		   GPIOB->BRR = OLED_SDA;//I2C_SDA_PORT->BRR = (1<<I2C_SDA_PIN);

	   _delay_loops(TimeX);
	   GPIOB->BSRR = OLED_SCL;//I2C_SCL_PORT->BSRR = (1<<I2C_SCL_PIN);
	   _delay_loops(TimeX);
	   GPIOB->BRR = OLED_SCL;//I2C_SCL_PORT->BRR = (1<<I2C_SCL_PIN);
	   data=data<<1;
	}
	_delay_loops(TimeX);
	GPIOB->BSRR = OLED_SCL; //I2C_SCL_PORT->BSRR = (1<<I2C_SCL_PIN);
	_delay_loops(TimeX);
	GPIOB->BRR = OLED_SCL;//I2C_SCL_PORT->BRR = (1<<I2C_SCL_PIN);
}

void __attribute__ ((noinline))  lcd_writeData (uint8_t byte)
{
	xpos++;
	I2C_WriteData(byte);
}


void I2C_Write(uint8_t address, uint8_t reg, uint8_t data)
{
	xpos++;

	I2C_Start();
	I2C_WriteData(address);
	I2C_WriteData(reg);
	I2C_WriteData(data);
	I2C_Stop();
}

void I2C_WriteMulti(uint8_t address, uint8_t reg, uint8_t* data, uint16_t count)
{
	uint8_t i;
	I2C_Start();
	I2C_WriteData(address);
	I2C_WriteData(reg);
	for (i = 0; i < count; i++)
		I2C_WriteData(data[i]);

	I2C_Stop();
}




/***************** LOW LEVEL ************************************************/
void delayus(int us)
{
	us *= 4;
	for(;us>0;us--) __NOP();
}

void __attribute__ ((noinline))  OLED_PortInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	//RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Pin    = OLED_SCL | OLED_SDA;
	GPIO_InitStructure.GPIO_Mode   = GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed  = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIOB->BSRR = OLED_SCL;
	GPIOB->BSRR = OLED_SDA;

	delayus(20);

}


void __attribute__ ((noinline))  lcd_init (int mode)
{

	OLED_PortInit();	

	SSD1306_WRITECOMMAND(0xAE);    /*display off*/

	SSD1306_WRITECOMMAND(0x02);    /*set lower column address*/
	SSD1306_WRITECOMMAND(0x10);    /*set higher column address*/

	SSD1306_WRITECOMMAND(0x40);    /*set display start line*/

	SSD1306_WRITECOMMAND(0xB0);    /*set page address*/

	SSD1306_WRITECOMMAND(0x81);    /*contract control*/
	SSD1306_WRITECOMMAND(0x80);    /*128*/

	SSD1306_WRITECOMMAND(0xA1);    /*set segment remap*/

	SSD1306_WRITECOMMAND(0xA6);    /*normal / reverse*/

	SSD1306_WRITECOMMAND(0xA8);    /*multiplex ratio*/
	SSD1306_WRITECOMMAND(0x3F);    /*duty = 1/32*/

	SSD1306_WRITECOMMAND(0xad);    /*set charge pump enable*/
	SSD1306_WRITECOMMAND(0x8b);     /*external VCC   */

	SSD1306_WRITECOMMAND(0x30);    /*0X30---0X33  set VPP   9V liangdu!!!!*/

	SSD1306_WRITECOMMAND(0xC8);    /*Com scan direction*/

	SSD1306_WRITECOMMAND(0xD3);    /*set display offset*/
	SSD1306_WRITECOMMAND(0x00);   /*   0x20  */

	SSD1306_WRITECOMMAND(0xD5);    /*set osc division*/
	SSD1306_WRITECOMMAND(0x80);

	SSD1306_WRITECOMMAND(0xD9);    /*set pre-charge period*/
	SSD1306_WRITECOMMAND(0x1f);    /*0x22*/

	SSD1306_WRITECOMMAND(0xDA);    /*set COM pins*/
	SSD1306_WRITECOMMAND(0x12);

	SSD1306_WRITECOMMAND(0xdb);    /*set vcomh*/
	SSD1306_WRITECOMMAND(0x40);


	xpos = 0;

	lcd_clear();
	SSD1306_WRITECOMMAND(0xAF); /*display ON*/
	TimeX = 5;
}

//
 // N1110 LCD hardware reset
 //!!!NOTE: needs normal delay implementation
 //
/*void __attribute__ ((noinline))  lcd_hw_reset (void){
	LCD_GPIO->BRR = LCD_RESET_PIN;
	delayus(10000);
	LCD_GPIO->BSRR = LCD_RESET_PIN;
	delayus(2000);
}

//
 // N1110 LCD write data or command
 //
void __attribute__ ((noinline))  lcd_write (lcd_cd_t cd, uint8_t byte){
	register uint32_t i;
	uint32_t b  = byte ;

	xpos++;
	//Slave select//
	LCD_GPIO->BRR = LCD_CS_PIN;

	if(vmirror && (cd ==DATA) ) b = __RBIT((uint32_t)b<<24);
	if(cd == DATA) b |= 1<<8;


	for(i=0; i<9; i++)
	{
		if(b & 0x100) LCD_GPIO->BSRR = ( LCD_SCK_PIN<<16 ) | LCD_SDA_PIN; //RESET SCK + SET SDA
		else 		LCD_GPIO->BSRR = ( (LCD_SDA_PIN | LCD_SCK_PIN )<<16);	//RESET SCK + SDA
		delayus(0);delayus(0);delayus(0);
		LCD_GPIO->BSRR = LCD_SCK_PIN;
		b <<= 1;
	}
	delayus(0);delayus(0);
	// Slave release 
	LCD_GPIO->BSRR = ( (LCD_SDA_PIN | LCD_SCK_PIN )<<16 ) | LCD_CS_PIN; //RESET SCK + SDA set CS
}*/

 //
 //Clear LCD screen
 //
void __attribute__ ((noinline))  lcd_clear (void)
{	
    uint8_t m;

	for (m = 0; m < 8; m++)
	{
		SSD1306_WRITECOMMAND(0xB0 + m);
		SSD1306_WRITECOMMAND(0x02);
		SSD1306_WRITECOMMAND(0x10);

		// Write multi data /
		I2C_WriteMulti(SSD1306_I2C_ADDR, 0x40, &SSD1306_Buffer[SSD1306_WIDTH * m], SSD1306_WIDTH);
	}
}

 //
 //Set current position
 //
void __attribute__ ((noinline))  lcd_gotoxy (uint8_t x ,uint8_t y){
	xpos = x;

	x = x + 2;
	SSD1306_WRITECOMMAND(0xB0 + y);         //set page address
    SSD1306_WRITECOMMAND(0x10 | (x >> 4) ); //set higher column address
    SSD1306_WRITECOMMAND(x & 0x0f); //set lower column address
}



void  lcd_putnum (int x, int y,char *str){

	char c;
	int i,j;

	char* str2 = str;


	for(i =0;i<3;i++)
	{
		lcd_gotoxy(x,y+2-i);

		str2 = str;
		
		I2C_Start();
        I2C_WriteData(SSD1306_I2C_ADDR);
        I2C_WriteData(0x40);
		
		while( (c = (*str2++)) )
		{
			if( (c>=0x30  &&  c<= 0x39)|| (c<11) )
			{
				int n = c - 0x30;
				if(n < 0) n = c+10;

				I2C_WriteData(mask);

				for(j=numbers_idx[n]+i; j< numbers_idx[n]+13*3 ; j+=3)
				{
					int dd = 0;
					if (j< numbers_idx[n+1]) dd = numbers[j];

					if ( (*str2 == '.') && (i==0)&&(j>( numbers_idx[n]+13*3 - 9))) dd |= 0x06;

					if (xpos <= SSD1306_WIDTH)
						I2C_WriteData(dd ^ mask);

				}
			}
		}
        I2C_WriteData(0x00);
        I2C_Stop();
	}
	//lcd_write(DATA,0);
}

/*
 * Put character to current position
 */
void __attribute__ ((noinline))  lcd_putchar (const char c){
	register uint32_t i;
	char cc = c;
	if(cc < 32) cc = 0; else cc -= 32;

    I2C_Start();
    I2C_WriteData(SSD1306_I2C_ADDR);
    I2C_WriteData(0x40);

	for(i=0; i<5; i++) if (xpos < SSD1306_WIDTH)
	{
		lcd_writeData( (lcd_font[((cc&0x7f)*5)+i])^ mask );
	}

	if (xpos <= SSD1306_WIDTH)
		lcd_writeData (0x00 ^ mask);
    I2C_Stop();
}

/*
 * Put string from RAM
 */
void __attribute__ ((noinline))  lcd_putstr (const char *str,int fill ){
	char c;
	while( (c = (*str++))  ) lcd_putchar(c);

	if (fill)
	{
	    I2C_Start();
        I2C_WriteData(SSD1306_I2C_ADDR);
        I2C_WriteData(0x40);
		while(xpos <= SSD1306_WIDTH)
			lcd_writeData(mask);
		//I2C_WriteData(0x00);
        I2C_Stop();
	}
}

void lcd_setcontrast(int c)
{
    //lcd_write(COMMAND, 0x80 |  (c&0x1F));
	SSD1306_WRITECOMMAND(0x81);    /*contract control*/
	SSD1306_WRITECOMMAND(c*6 + 47);    /*128*/
}
